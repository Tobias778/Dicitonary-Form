﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DictionaryForm
{
    
    public partial class Form1 : Form
    {
        Dictionary<int, string> myList = new Dictionary<int, string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            myList.Add(Convert.ToInt32(textBoxID.Text), textBoxName.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            updateTable();
        }
        public void updateTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Name");
            foreach (var entry in myList)
            {
                // MessageBox.Show(entry.Key.ToString(), entry.Value);
                dt.Rows.Add(entry.Key, entry.Value);
                dataGridView1.DataSource = dt;
                cleanTextBox();
            }
        }

        public void cleanTextBox()
        {
            textBoxID.Clear();
            textBoxName.Clear();
        }

     
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            myList.Remove(Convert.ToInt32(textBoxID.Text));
            //MessageBox.Show("Entry Deleted");
            dataGridView1.DataSource = null;
            this.dataGridView1.Rows.Clear();
            updateTable();
            cleanTextBox();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            // key value does not change

            int key = Convert.ToInt32(textBoxID.Text);
            string newVal = textBoxName.Text;

            if (!myList.ContainsKey(key))
                myList.Add(key, newVal);
            else
                myList[key] = newVal; 
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                textBoxID.Text = dataGridView1.SelectedRows[0].Cells["ID"].Value.ToString();
                textBoxName.Text = dataGridView1.SelectedRows[0].Cells["Name"].Value.ToString();
            }
        }
    }
}
